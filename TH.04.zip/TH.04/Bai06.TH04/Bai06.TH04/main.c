//
//  main.c
//  Bai06.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//. Viết hàm tính  1 + 22 + 33 + … + nn
int sumOfSeries(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        int term = 1;
        for (int j = 1; j <= i; j++) {
            term *= j;
        }
        sum += term;
    }
    return sum;
}

int main() {
    int n;
    printf("Nhap so nguyen duong: ");
    scanf("%d", &n);
    int result = sumOfSeries(n);
    printf("Tong cua chuoi la: %d", result);
    return 0;
}
