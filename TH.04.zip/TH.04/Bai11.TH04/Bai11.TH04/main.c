//
//  main.c
//  Bai11.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
#include <math.h>
//Viết hàm in ra màn hình các số nguyên tố nhỏ hơn n.
int i;
int isPrime(int num) {
    if (num <= 1) {
        return 0;
    }
    for (int i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) {
            return 0;
        }
    }
    return 1;
}

void printPrimesLessThan(int n) {
    int i = 2;
    while (i < n) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
        i++;
    }
}

int main() {
    int n;
    printf("Nhap N: ");
    scanf("%d", &n);
    printPrimesLessThan(n);
    return 0;
}
