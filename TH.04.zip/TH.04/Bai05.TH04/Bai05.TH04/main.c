//
//  main.c
//  Bai05.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//Viết hàm tính  1! + 2! + … + n!
int factorial(int n) {
    int i;
    int result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    int result = factorial(n);
    printf("Factorial of %d is %d", n, result);
    return 0;
}
