//
//  main.c
//  Bai07.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//Viết hàm tính  1 + 2n + 3n + … + nn
int tinh_tong(int n) {
  int S = 0;

  for (int i = 1; i <= n; i++) {
    int x = i * i;

    S += x;
  }


  return S;
}

int main() {
  int n;
  printf("Nhap so tu nhien n: ");
  scanf("%d", &n);

  int S = tinh_tong(n);

  printf("Tổng S = 1 + 2^n + 3^n + ... + n^n = %d\n", S);
    return 0;
}
