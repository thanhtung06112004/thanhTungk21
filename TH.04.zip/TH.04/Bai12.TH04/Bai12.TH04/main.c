//
//  main.c
//  Bai12.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
#include <math.h>
//Viết hàm tính tổng, hiệu, tích, thương của 2 số nguyên.
void Tinh(int x, int y, int *Tong, int *Hieu, int *Tich, float *Thuong) {
    *Tong = x + y;
    *Hieu = x - y;
    *Tich = x * y;
    *Thuong = (float)x / y;
}
 

    int main() {
        int a, b;
        int tong, hieu, tich;
        float thuong;
        printf("Nhap so thu nhap a: ");
        scanf("%d", &a);
        printf("Nhap so thu nhap b: ");
        scanf("%d", &b);
        Tinh(a, b, &tong, &hieu, &tich, &thuong);
        printf("Tong la: %d\n", tong);
        printf("Hieu la: %d\n", hieu);
        printf("Tich la: %d\n", tich);
        printf("Thuong la: %.2f\n", thuong);
    
    return 0;
}
