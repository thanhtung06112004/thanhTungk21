//
//  main.c
//  Bai01.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
#include <math.h>
//Viết hàm tính tổng 1 + 2 + … + n.
int sum(int n);

int main() {
  int n;
  printf("Nhập số n: ");
  scanf("%d", &n);

  int sum = sum(n);
  printf("Tổng 1 + 2 + ..... + %d = %d\n", n, sum);

  return 0;
}

int sum(int n) {
  int i, sum = 0;
  for (i = 1; i <= n; i++) {
    sum += i;
  }
  return sum;
}
