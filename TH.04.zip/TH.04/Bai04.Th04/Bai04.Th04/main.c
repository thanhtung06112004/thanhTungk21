//
//  main.c
//  Bai04.Th04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//Viết hàm tính  1/2 + 2/3 + … + (n-1)/n
float sumOfSeries(int n) {
    float sum = 0;
    for (int i = 1; i < n; i++) {
        sum += (float)i / (float)n;
    }
    return sum;
}

int main() {
    int n;
    printf("Nhap gia tri n: ");
    scanf("%d", &n);
    float result = sumOfSeries(n);
    printf("Tong gia tri n la: %.2f", result);
    return 0;
}
