//
//  main.c
//  Bai13.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
#include <math.h>
//. Viết hàm tính chu vi, diện tích của 1 tam giác.

float chu_vi_tam_giac(float a, float b, float c) {
  return a + b + c;
}

float dien_tich_tam_giac(float a, float b, float c) {
  float s = (a + b + c) / 2;
  return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
  float a, b, c;
  printf("Nhap do dai canh a: ");
  scanf("%f", &a);
  printf("Nhap do dai canh b: ");
  scanf("%f", &b);
  printf("Nhap do dai canh c: ");
  scanf("%f", &c);

  float chu_vi = chu_vi_tam_giac(a, b, c);
  float dien_tich = dien_tich_tam_giac(a, b, c);

  printf("Chu vi tam giac la: %.2f\n", chu_vi);
  printf("Dien tich tam giac la: %.2f\n", dien_tich);

    return 0;
}
