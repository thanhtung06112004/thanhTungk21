//
//  main.c
//  Bai03.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//. Viết hàm tính  1 + 1/2 + … + 1/n
float tinh_tong(int n) {
  float tong = 0;
  for (int i = 1; i <= n; i++) {
    tong += 1.0 / i;
  }
  return tong;
}

int main(int argc, const char * argv[]) {
    int n;
      printf("Nhap n: ");
      scanf("%d", &n);

      float tong = tinh_tong(n);
      printf("1 + 1/2 + ... + 1/%d = %.2f\n", n, tong);

    return 0;
}
