//
//  main.c
//  Bai03.Th06
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

typedef struct {
  double x;
  double y;
} Complex;

// Nhập 1 số phức
void inputComplex(Complex *c) {
  printf("Nhap phan thuc cua so phuc: ");
  scanf("%lf", &c->x);
  printf("Nhap phan ao cua so phuc: ");
  scanf("%lf", &c->y);
}

Complex addComplex(Complex c1, Complex c2) {
  Complex res;
  res.x = c1.x + c2.x;
  res.y = c1.y + c2.y;
  return res;
}

Complex multiplyComplex(Complex c1, Complex c2) {
  Complex res;
  res.x = c1.x * c2.x - c1.y * c2.y;
  res.y = c1.x * c2.y + c1.y * c2.x;
  return res;
}

int main() {
  Complex c1, c2;

  // Nhập 2 số phức
  inputComplex(&c1);
  inputComplex(&c2);

  Complex sum = addComplex(c1, c2);

  Complex product = multiplyComplex(c1, c2);

  // Hiển thị kết quả
  printf("Tong 2 so phuc la: %.2lf + %.2lfi\n", sum.x, sum.y);
  printf("Tich 2 so phuc la: %.2lf + %.2lfi\n", product.x, product.y);

  return 0;
}
   
