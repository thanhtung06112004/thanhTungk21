//
//  main.c
//  Bai04.TH06
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>
struct Time {
  int hour;
  int minute;
  int second;
};

void inputTime(struct Time *time) {
  printf("Nhap gio: ");
  scanf("%d", &time->hour);
  printf("Nhap phut: ");
  scanf("%d", &time->minute);
  printf("Nhap giay: ");
  scanf("%d", &time->second);
}

void increaseTime(struct Time *time, int x) {
  time->second += x;
  if (time->second >= 60) {
    time->minute++;
    time->second -= 60;
  }
  if (time->minute >= 60) {
    time->hour++;
    time->minute -= 60;
  }
}

int main() {
  struct Time time;

  inputTime(&time);

  increaseTime(&time, 10);

  printf("Thoi gian hien tai la: %d:%d:%d\n", time.hour, time.minute, time.second);

  return 0;
}
