//
//  main.c
//  Bai1.TH01
//
//  Created by le thanh tung on 12/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Bài 1. Hãy in ra màn hình các dòng:
//    a.    Chào các bạn
//    b.    Chào        các        bạn
    // Hiển thị dòng "Chào các bạn"
      printf("Chào các bạn\n");

      // Hiển thị dòng "Chào các ban"
      printf("Chào các ban\n");

    return 0;
}
