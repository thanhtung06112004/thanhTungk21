//
//  main.c
//  Bai03.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình tính tổng S = 1 + 1/2 + … + 1/n.
    int n;
      float sum = 0;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      for (int i = 1; i <= n; i++) {
        sum += 1.0f / i;
      }

      printf("Tổng S = 1 + 1/2 + ... + 1/n = %.2f\n", sum);

    return 0;
}
