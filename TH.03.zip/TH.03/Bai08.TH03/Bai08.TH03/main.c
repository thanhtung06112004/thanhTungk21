//
//  main.c
//  Bai08.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int n;
      float sum = 0;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      for (int i = 1; i <= n; i++) {
        sum += 1.0f / i;
      }

      printf("Tổng S = 1 + 1/2 + 1/3 + ... + 1/n = %.2f\n", sum);
    return 0;
}
