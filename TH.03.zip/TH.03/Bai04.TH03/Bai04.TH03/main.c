//
//  main.c
//  Bai04.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình tính tổng S = 1/2 + 2/3 + … + (n-1)/n.
    int n;
      float sum = 0;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      for (int i = 1; i < n; i++) {
        sum += (float)i / (i + 1);
      }

      printf("Tổng S = 1/2 + 2/3 + ... + (n - 1)/n = %.2f\n", sum);

    return 0;
}
