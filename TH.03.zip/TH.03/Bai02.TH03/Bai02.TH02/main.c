//
//  main.c
//  Bai02.TH02
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình tính tích P = 1*2* … *n.
    int n;
      float sum = 1;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      for (int i = 1; i <= n; i++) {
        sum *= (float)i;
      }

      printf("Tích P = 1 2n = %.2f\n", sum);

    return 0;
}
