//
//  main.c
//  Bai11.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình kiểm tra một số nguyên N nhập vào từ bàn phím có phải là số nguyên tố không?
    int n;

      printf("Nhập so nguyen duong n: ");
      scanf("%d", &n);

      if (n <= 1) {
        printf("So %d khong phai la so nguyen to.\n", n);
        return 0;
      }

      for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
          printf("So %d khong phai la so nguyen to.\n", n);
          return 0;
        }
      }

      printf("So %d la so nguyen to.\n", n);
    return 0;
}
