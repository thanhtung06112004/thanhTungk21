//
//  main.c
//  Bai10.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình xác định xem một tờ giấy có độ dày 0.1 mm. Phải gấp đôi tờ giấy bao nhiêu lần để nó có độ dày >1m (bằng 1000 mm).
    int main() {
      // Độ dày ban đầu của tờ giấy
      float do_day_ban_dau = 0.1;
      // Độ dày cần đạt được
      float do_day_can_dat_duoc = 1000;
      // Số lần gấp đôi cần thiết
      int so_lan_gap_doi = 0;

      // Tính toán số lần gấp đôi
      while (do_day_ban_dau * 2 < do_day_can_dat_duoc) {
        do_day_ban_dau *= 2;
        so_lan_gap_doi++;
      }

      // In kết quả
      printf("So lan gap doi to giay de co do day la: %d\n", so_lan_gap_doi);

      return 0;
    }
