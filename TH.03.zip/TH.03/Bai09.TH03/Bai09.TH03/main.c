//
//  main.c
//  Bai09.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>
#include <math.h>
int main(int argc, const char * argv[]) {
//    Viết chương trình tính S = 1 + 1/x + 2/x2 + 3/x3 + … + n/xn
    int n;
      float sum = 0;
      float x;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      printf("Nhập x: ");
      scanf("%f", &x);

      for (int i = 1; i <= n; i++) {
        sum += i / pow(x, i);
      }

      printf("Tổng S = 1 + 1/x + 2/x^2 + ... + n/x^n = %.2f\n", sum);
    return 0;
}
