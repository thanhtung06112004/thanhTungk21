
#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình nhập vào số nguyên dương, in ra thông báo số chẵn hay lẻ.
    int n;
    
      printf("Nhap vao so nguyn duong: ");
      scanf("%d", &n);

      if (n % 2 == 0) {
        printf("So %d la so chan.\n", n);
      } else {
        printf("So %d la so le.\n", n);
      }
    return 0;
}
