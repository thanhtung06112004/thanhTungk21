#include <stdlib.h>

int main() {
  int nguoi, may;
  char tiep_tu = 'y';

  while (tiep_tu == 'y') {
    // Cho người dùng chọn
    printf("Chọn của bạn: (1: kéo, 2: búa, 3: bao)\n");
    scanf("%d", &nguoi);

    // Máy luôn chọn bao
    may = 3;

    // So sánh kết quả
    switch (nguoi) {
      case 1:
        printf("May thang!\n");
        break;
      case 2:
        printf("May thang!\n");
        break;
      case 3:
        printf("Nguoi choi thang!\n");
        break;
    }

    // Hỏi người dùng tiếp tục hay không
    printf("Tiep tuc (y/n)?\n");
    scanf(" %c", &tiep_tu);
  }

  return 0;
}
