

#include <stdio.h>
#include <math.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình nhập vào điểm 3 môn thi: Toán, Lý, Hóa của học sinh. Nếu tổng điểm >= 15 và không có môn nào dưới 4 thì in kết quả đậu. Nếu đậu mà các môn đều lớn hơn 5 thì in ra lời phê "Học đều các môn", ngược lại in ra "Học chưa đều các môn", các trường hợp khác là "Thi hỏng".
    float diemToan, diemLy, diemHoa;

      // Nhập vào điểm 3 môn thi
      printf("Nhap diem Toan: ");
      scanf("%f", &diemToan);
      printf("Nhap diem Ly: ");
      scanf("%f", &diemLy);
      printf("Nhap diem Hoa: ");
      scanf("%f", &diemHoa);

      // Kiểm tra điều kiện đậu
      if (diemToan >= 4 && diemLy >= 4 && diemHoa >= 4 && (diemToan + diemLy + diemHoa) >= 15) {
        // Nếu đậu thì in kết quả
        printf("Đậu.\n");

        // Nếu đậu mà các môn đều lớn hơn 5 thì in ra lời phê "Học đều các môn"
        if (diemToan >= 5 && diemLy >= 5 && diemHoa >= 5) {
          printf("Hoc deu cac mon.\n");
        } else {
          printf("Hoc chua deu cac mon.\n");
        }
      } else {
        // Nếu không đậu thì in ra thông báo
        printf("Thi sinh khong dau.\n");
      }

    return 0;
}
