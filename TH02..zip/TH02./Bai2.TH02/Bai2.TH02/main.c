

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    . Viết chương trình nhập vào 3 số nguyên, hãy tìm giá trị cực đại trong 3 số vừa nhập.
    
    int a, b, c;
    
    printf("Nhap vao 3 so nguyen: ");
    scanf("%d%d%d", &a, &b, &c);
    
    int max = a;
    if (b > a) {
        max = b;
    }
    if (c = max) {
        max = c;
    }
    printf("gia tri cuc dai la: %d\n", max);
    
    return 0;
}
