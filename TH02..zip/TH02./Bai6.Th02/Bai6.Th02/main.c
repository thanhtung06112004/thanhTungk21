//
//  main.c
//  Bai6.Th02
//
//  Created by le thanh tung on 12/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình tính tiền điện gồm các khoảng sau:
//    - Tiền thuê bao điện kế: 1000đ/tháng
//    - Định mức sử dụng điện cho mỗi hộ là: 50 KW với giá 230đ/KW
//    - Nếu phần vượt định mức <= 50KW thì tính giá 480đ/KW
//    - Nếu 50KW < phần vượt định mức < 100KW thì tính giá 700đ/KW
//    - Nếu phần vượt định mức <= 100KW thì tính giá 900đ/KW
//    Chỉ số mới và cũ được nhập vào từ bàn phím
//    - In ra màn hình chỉ số cũ, chỉ số mới, tổng tiền phải trả

    int chiSoCu, chiSoMoi;

      // Nhập chỉ số cũ và mới
      printf("nhap chi so cu: ");
      scanf("%d", &chiSoCu);
      printf("nhap chi so moi: ");
      scanf("%d", &chiSoMoi);

      // Tính số điện tiêu thụ
      int soDienTieuThu = chiSoMoi - chiSoCu;

      // Tính tiền điện phải trả
      int tienDien = 0;
      if (soDienTieuThu <= 50) {
        tienDien = soDienTieuThu * 2304;
      } else if (soDienTieuThu <= 100) {
        tienDien = 50 * 2304 + (soDienTieuThu - 50) * 480;
      } else {
        tienDien = 50 * 2304 + 50 * 480 + (soDienTieuThu - 100) * 700;
      }

      // Tính tiền thuê bao điện kế
      int tienThueBaoDienKe = 1000;

      // Tính tổng tiền phải trả
      int tongTien = tienDien + tienThueBaoDienKe;

      // In ra kết quả
      printf("Chi so cu: %d\n", chiSoCu);
      printf("Chi so moi: %d\n", chiSoMoi);
      printf("So dien tieu thu: %d\n", soDienTieuThu);
      printf("tien dien phai tra: %d\n", tienDien);
      printf("tien thue bao dien ke: %d\n", tienThueBaoDienKe);
      printf("tong tien phai tra: %d\n", tongTien);
    return 0;
}
