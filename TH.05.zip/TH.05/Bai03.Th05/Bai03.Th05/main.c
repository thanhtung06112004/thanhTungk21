//
//  main.c
//  Bai03.Th05
//
//  Created by le thanh tung on 15/11/2023.
//

#include <stdio.h>
#include  <stdbool.h>

void nhapmang(int a[], int n) {
  for (int i = 0; i < n; i++) {
    printf("a[%d] = ", i);
    scanf("%d", &a[i]);
  }
}

bool kiemtra_mang_duong(int a[], int n) {
  for (int i = 0; i < n; i++) {
    if (a[i] < 0) {
      return false;
    }
  }

  return true;
}

bool kiemtra_mang_doixung(int a[], int n) {
  for (int i = 0; i < n / 2; i++) {
    if (a[i] != a[n - 1 - i]) {
      return false;
    }
  }

  return true;
}

bool kiemtra_mang_tangdan(int a[], int n) {
  for (int i = 1; i < n; i++) {
    if (a[i - 1] > a[i]) {
      return false;
    }
  }

  return true;
}

bool kiemtra_mang_capsocong(int a[], int n) {
  int delta = a[1] - a[0];

  for (int i = 2; i < n; i++) {
    if (a[i] != a[i - 1] + delta) {
      return false;
    }
  }

  return true;
}

int main() {
  int n;
  printf("Nhập số phần tử của mảng: ");
  scanf("%d", &n);

  int a[n];
  nhapmang(a, n);

  if (kiemtra_mang_duong(a, n)) {
    printf("Mảng chứa các phần tử dương.\n");
  } else {
    printf("Mảng không chứa các phần tử dương.\n");
  }

  if (kiemtra_mang_doixung(a, n)) {
    printf("Mảng đối xứng.\n");
  } else {
    printf("Mảng không đối xứng.\n");
  }

  if (kiemtra_mang_tangdan(a, n)) {
    printf("Mảng tăng dần.\n");
  } else {
    printf("Mảng không tăng dần.\n");
  }

  if (kiemtra_mang_capsocong(a, n)) {
    printf("Mảng cấp số cộng.\n");
  } else {
    printf("Mảng không cấp số cộng.\n");
  }

  return 0;
}
